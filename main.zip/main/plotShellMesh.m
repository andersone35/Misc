function plotShellMesh(nodes,elements)
    edgePoints = getEdgePoints(nodes,elements);
    ndSizes = 36*ones(length(nodes),1);
    edgeSizes = 4*ones(length(edgePoints),1);
    sz = [ndSizes;edgeSizes];
    allPts = [nodes;edgePoints];
    scatter3(allPts(:,1),allPts(:,2),allPts(:,3),sz)
end

