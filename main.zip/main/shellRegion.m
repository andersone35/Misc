classdef shellRegion
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        type = '';
        keyPts = [];
        edgeEls = [];
    end
    
    methods
        function obj = shellRegion(regType,keyPoints,numEdgeEls)
            obj.type = regType;
            obj.keyPts = keyPoints;
            obj.edgeEls = numEdgeEls;
        end
        
        function [nodes,elements] = createShellMesh(obj,elType,method)
            if(contains(method,'structured'))
                if(contains(obj.type,'quad') || contains(obj.type,'cyl'))
                else
                    error('Only quadrilateral or cylinder shell regions can use the structured meshing option')
                end
            else
                [boundaryNodes,edges] = obj.initialBoundary();
                plot2DMesh(boundaryNodes,[]);
                keyboard
                mesh = NuMesh2D(boundaryNodes,edges(:,1:2));
                [etaNodes,elements,mesh] = mesh.createPlanarMesh(elType,1);
                nodes = [];
                for i = 1:length(etaNodes)
                    XYZ = obj.XYZCoord(etaNodes(i,:));
                    nodes = [nodes;XYZ];
                end
            end
        end
        
        function [nodes,edges] = initialBoundary(obj)
            if(contains(obj.type,'quad'))
                nodes = [];
                edges = [];
                %% initialize nodes on side 1
                delE = 2/obj.edgeEls(1);
                for i = 1:obj.edgeEls(1)
                    e1 = delE*i-1;
                    pt = [e1,-1];
                    nodes = [nodes;pt];
                end
                %% initialize nodes on side 2
                delE = 2/obj.edgeEls(2);
                for i = 1:obj.edgeEls(2)
                    e2 = delE*i-1;
                    pt = [1,e2];
                    nodes = [nodes;pt];
                end
                %% initialize nodes on side 3
                delE = 2/obj.edgeEls(3);
                for i = 1:obj.edgeEls(3)
                    e1 = 1-delE*i;
                    pt = [e1,1];
                    nodes = [nodes;pt];
                end
                %% initialize nodes on side 4
                delE = 2/obj.edgeEls(4);
                for i = 1:obj.edgeEls(4)
                    e2 = 1 - delE*i;
                    pt = [-1,e2];
                    nodes = [nodes;pt];
                end
                for i = 1:length(nodes) - 1
                    ed = [i,i+1,-1,0,0,0];
                    edges = [edges;ed];
                end
                ed = [length(nodes),1,-1,0,0,0];
                edges = [edges;ed];
            end
        end
        
        function [XYZ] = XYZCoord(obj,eta)
            switch obj.type
                case 'quad4'
                    Nvec = zeros(1,4);
                    Nvec(1) = 0.25*(eta(1)-1)*(eta(2)-1);
                    Nvec(2) = -0.25*(eta(1)+1)*(eta(2)-1);
                    Nvec(3) = 0.25*(eta(1)+1)*(eta(2)+1);
                    Nvec(4) = -0.25*(eta(1)-1)*(eta(2)+1);
                    XYZ = Nvec*obj.keyPts;
                case 'quad9'
                    r1 = -1;
                    r2 = 0;
                    r3 = 1;
                    Nvec = zeros(1,9);
                    Nvec(1) = 0.25*(eta(1)-r2)*(eta(1)-r3)*(eta(2)-r2)*(eta(2)-r3);
                    Nvec(2) = 0.25*(eta(1)-r1)*(eta(1)-r2)*(eta(2)-r2)*(eta(2)-r3);
                    Nvec(3) = 0.25*(eta(1)-r1)*(eta(1)-r2)*(eta(2)-r1)*(eta(2)-r2);
                    Nvec(4) = 0.25*(eta(1)-r2)*(eta(1)-r3)*(eta(2)-r1)*(eta(2)-r2);
                    Nvec(5) = -0.5*(eta(1)-r1)*(eta(1)-r3)*(eta(2)-r2)*(eta(2)-r3);
                    Nvec(6) = -0.5*(eta(1)-r1)*(eta(1)-r2)*(eta(2)-r1)*(eta(2)-r3);
                    Nvec(7) = -0.5*(eta(1)-r1)*(eta(1)-r3)*(eta(2)-r1)*(eta(2)-r2);
                    Nvec(8) = -0.5*(eta(1)-r2)*(eta(1)-r3)*(eta(2)-r1)*(eta(2)-r3);
                    Nvec(9) = (eta(1)-r1)*(eta(1)-r3)*(eta(2)-r1)*(eta(2)-r3);
                    XYZ = Nvec*obj.keyPts;
                case 'quad16'
                    r1 = -1;
                    r2 = -0.333333333333333;
                    r3 = 0.333333333333333;
                    r4 = 1;
                    coef = [0.31640625,-0.31640625,0.31640625,-0.31640625,...
                      -0.94921875,0.94921875,0.94921875,-0.94921875,...
                      -0.94921875,0.94921875,0.94921875,-0.94921875,...
                       2.84765625,-2.84765625,2.84765625,-2.84765625];
                    Nvec = zeros(1,16);
                    Nvec(1) = (eta(1)-r2)*(eta(1)-r3)*(eta(1)-r4)*(eta(2)-r2)*(eta(2)-r3)*(eta(2)-r4);
                    Nvec(2) = (eta(1)-r1)*(eta(1)-r2)*(eta(1)-r3)*(eta(2)-r2)*(eta(2)-r3)*(eta(2)-r4);
                    Nvec(3) = (eta(1)-r1)*(eta(1)-r2)*(eta(1)-r3)*(eta(2)-r1)*(eta(2)-r2)*(eta(2)-r3);
                    Nvec(4) = (eta(1)-r2)*(eta(1)-r3)*(eta(1)-r4)*(eta(2)-r1)*(eta(2)-r2)*(eta(2)-r3);
                    Nvec(5) = (eta(1)-r1)*(eta(1)-r3)*(eta(1)-r4)*(eta(2)-r2)*(eta(2)-r3)*(eta(2)-r4);
                    Nvec(6) = (eta(1)-r1)*(eta(1)-r2)*(eta(1)-r4)*(eta(2)-r2)*(eta(2)-r3)*(eta(2)-r4);
                    Nvec(7) = (eta(1)-r1)*(eta(1)-r2)*(eta(1)-r3)*(eta(2)-r1)*(eta(2)-r3)*(eta(2)-r4);
                    Nvec(8) = (eta(1)-r1)*(eta(1)-r2)*(eta(1)-r3)*(eta(2)-r1)*(eta(2)-r2)*(eta(2)-r4);
                    Nvec(9) = (eta(1)-r1)*(eta(1)-r2)*(eta(1)-r4)*(eta(2)-r1)*(eta(2)-r2)*(eta(2)-r3);
                    Nvec(10) = (eta(1)-r1)*(eta(1)-r3)*(eta(1)-r4)*(eta(2)-r1)*(eta(2)-r2)*(eta(2)-r3);
                    Nvec(11) = (eta(1)-r2)*(eta(1)-r3)*(eta(1)-r4)*(eta(2)-r1)*(eta(2)-r2)*(eta(2)-r4);
                    Nvec(12) = (eta(1)-r2)*(eta(1)-r3)*(eta(1)-r4)*(eta(2)-r1)*(eta(2)-r3)*(eta(2)-r4);
                    Nvec(13) = (eta(1)-r1)*(eta(1)-r3)*(eta(1)-r4)*(eta(2)-r1)*(eta(2)-r3)*(eta(2)-r4);
                    Nvec(14) = (eta(1)-r1)*(eta(1)-r2)*(eta(1)-r4)*(eta(2)-r1)*(eta(2)-r3)*(eta(2)-r4);
                    Nvec(15) = (eta(1)-r1)*(eta(1)-r2)*(eta(1)-r4)*(eta(2)-r1)*(eta(2)-r2)*(eta(2)-r4);
                    Nvec(16) = (eta(1)-r1)*(eta(1)-r3)*(eta(1)-r4)*(eta(2)-r1)*(eta(2)-r2)*(eta(2)-r4);
                    Nvec = coef.*Nvec;
                    XYZ = Nvec*obj.keyPts;
            end
        end

    end
end

