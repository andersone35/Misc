elType = 'tri';
numBound = 48;

thetaInc = 2*pi/numBound;
boundaryNodes = [];
for i = 1:numBound
    theta = thetaInc*(i-1);
%     x = cos(theta);
%     y = sin(theta);
    x = 1 - sin(0.5*theta);
    y = 0.1*sin(theta);
    boundaryNodes = [boundaryNodes;[x,y]];
end

mesh = NuMesh2D(boundaryNodes,[]);

% elNds = [0,0;1,0;0,1;0.5,-1;1.5,-1;1.5,0];
% els= [1,2,3;4,5,6];
% overlap = mesh.elementsOverlap(els,elNds,1)
[nodes,elements,mesh] = mesh.createPlanarMesh(elType,1);

