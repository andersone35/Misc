function plot2DMesh(nodes,elements)
    edgePoints = getEdgePoints(nodes,elements);
    ndSizes = 36*ones(length(nodes),1);
    edgeSizes = 4*ones(length(edgePoints),1);
    sz = [ndSizes;edgeSizes];
    allPts = [nodes;edgePoints];
    scatter(allPts(:,1),allPts(:,2),sz);
end

