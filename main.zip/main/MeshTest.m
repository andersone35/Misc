regType = 'quad9';
elType = 'quad';
keyPoints = [0,0,0;...
    2,0,0;...
    1.5,2,0.5;...
    0.5,2,0;...
    1,0,0.5;...
    2,1,-0.5;...
    1,2,0.5;...
    0,1,-0.5;
    1,1,0];
numEdgeEls = [15;15;10;15];
method = 'free';

shell = shellRegion(regType,keyPoints,numEdgeEls);
[nodes,elements] = shell.createShellMesh(elType,method);
plotShellMesh(nodes,elements);

% [nodes,elements] = createShellMesh(regType,elType,keyPoints,numEdgeEls,method);

% [boundaryNodes,boundaryEdges] = initializeShellBoundary(regType,elType,keyPoints,numEdgeEls);
% boundaryEdges = getBoundEdgeNormals(boundaryEdges,boundaryNodes);
% keyboard
% [nodes,edges,elements] = create2DMesh(boundaryNodes,boundaryEdges);
% plot2DMesh(nodes(:,1:2),elements);
% [nodes,edges,elSize] = initializeShellBoundary(regType,elType,keyPoints,numEdgeEls);
% [uNodes,gridSize] = uniformBoundarySpacing(nodes(:,1:2),10);
% scatter(uNodes(:,1),uNodes(:,2));
% numIt = 10;
% for i = 1:numIt
%     [nextNds,gridSize] = uniformBoundarySpacing(nodes(:,1:2));
%     scatter(nextNds(:,1),nextNds(:,2));
%     pause(5);
%     nodes = nextNds;
% end
% [nodes,elements] = createShellMesh(regType,elType,keyPoints,numEdgeEls,method);
% 
% edgePoints = getEdgePoints(nodes,elements);
% allPts = [nodes;edgePoints];
% 
% scatter(allPts(:,1),allPts(:,2));