classdef gridStatus2D
    %UNTITLED4 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        status = [];
        xMin = 0;
        yMin = 0;
        gdSz = 1;
        xRows = 1;
        yRows = 1;
    end
    
    methods
        function obj = gridStatus2D(minimumX,maximumX,minimumY,maximumY,gridSize)
            obj.xMin = minimumX;
            obj.yMin = minimumY;
            obj.gdSz = gridSize;
            obj.xRows = ceil((maximumX-minimumX)/gridSize) + 1;
            obj.yRows = ceil((maximumY-minimumY)/gridSize) + 1;
            obj.status = zeros(obj.xRows,obj.yRows);
        end
        
        function [newEdges] = getBoundEdgeNormals(obj,edges,nodes)
            newEdges = edges;
            for k = 1:length(newEdges)
                n1 = newEdges(k,1);
                n2 = newEdges(k,2);
                midpt = 0.5*(nodes(n2,:) + nodes(n1,:));
                eVec = nodes(n2,:) - nodes(n1,:);
                nVec = [-eVec(2), eVec(1)];
                iMax = ceil((midpt(1) + 4*obj.gdSz - obj.xMin)/obj.gdSz) + 1;
                iMin = floor((midpt(1) - 4*obj.gdSz - obj.xMin)/obj.gdSz);
                jMax = ceil((midpt(2) + 4*obj.gdSz - obj.yMin)/obj.gdSz) + 1;
                jMin = floor((midpt(2) - 4*obj.gdSz - obj.yMin)/obj.gdSz);
                interDir = [0,0];
                for i = iMin:iMax
                    for j = jMin:jMax
                        if(obj.status(i,j) == 2)
                            gX = obj.xMin + obj.gdSz*(i-1);
                            gY = obj.yMin + obj.gdSz*(j-1);
                            pt = [gX,gY];
                            vec = pt - midpt;
                            dist = sqrt(vec*vec');
                            unitVec = (1/dist)*vec;
                            interDir = interDir + unitVec;
                        end
                    end
                end
                dp = nVec*interDir';
                if(dp < 0)
                    nVec = -nVec;
                end
                mag = sqrt(nVec*nVec');
                newEdges(k,5:6) = (1/mag)*nVec;
            end
        end

        function obj = getInteriorGrid(obj,boundaryNodes,edges)
            numNds = length(boundaryNodes);
            numEdges = size(edges,1);
            newPts = [];

            for i = 1:numEdges
                n1 = edges(i,1);
                n2 = edges(i,2);
                vec = boundaryNodes(n2,:) - boundaryNodes(n1,:);
                mag = sqrt(vec*vec');
                numEpts = floor(mag/obj.gdSz);
                for j = 1:numEpts
                    newPt = boundaryNodes(i,:) + (1/(numEpts+1))*j*vec;
                    newPts = [newPts;newPt];
                end
            end

            allPts = [boundaryNodes;newPts];
            
            obj.status(:,:) = 0;
            for k = 1:length(allPts)
                iRow = round((allPts(k,1) - obj.xMin)/obj.gdSz) + 1;
                jRow = round((allPts(k,2) - obj.yMin)/obj.gdSz) + 1;
                for i = iRow-1:iRow+1
                    for j = jRow-1:jRow+1
                        obj.status(i,j) = 2;
                    end
                end
            end

            obj.status(1,1) = -1;
            elimPts = [1,1];
            currentPt = 1;
            while(currentPt <= length(elimPts))
                thisPt = elimPts(currentPt,:);
                iMax = min([obj.xRows,thisPt(1)+1],[],'all');
                iMin = max([1,thisPt(1)-1],[],'all');
                jMax = min([obj.yRows,thisPt(2)+1],[],'all');
                jMin = max([1,thisPt(2)-1],[],'all');
                for i = iMin:iMax
                    for j = jMin:jMax
                        if(obj.status(i,j) == 0)
                            obj.status(i,j) = -1;
                            elimPts = [elimPts;[i,j]];
                        end
                    end
                end
                currentPt = currentPt + 1;
            end

            for i = 1:obj.xRows
                for j = 1:obj.yRows
                    if(obj.status(i,j) == 0)
                        obj.status(i,j) = 2;
                    end
                end
            end
        end
        
        function [stat] = getStatusAt(obj,pt)
            iRow = round((pt(1) - obj.xMin)/obj.gdSz) + 1;
            jRow = round((pt(2) - obj.yMin)/obj.gdSz) + 1;
            stat = obj.status(iRow,jRow);
        end
        
        
        
    end
end

