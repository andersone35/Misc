function [edgePts] = getEdgePoints(nodes,elements)
    edgePts = [];
    [numEls,numElCols] = size(elements);
    for i = 1:numEls
        numNds = 0;
        for j = 1:numElCols
            if(elements(i,j) ~= 0)
                numNds = numNds + 1;
            end
        end
        for j = 1:numNds-1
            n1 = nodes(elements(i,j),:);
            n2 = nodes(elements(i,j+1),:);
            vec = n2 - n1;
            for k = 1:5
                pt = n1 + k*0.16666*vec;
                edgePts = [edgePts;pt];
            end
        end
        n1 = nodes(elements(i,numNds),:);
        n2 = nodes(elements(i,1),:);
        vec = n2 - n1;
        for k = 1:5
            pt = n1 + k*0.16666*vec;
            edgePts = [edgePts;pt];
        end
    end
end

